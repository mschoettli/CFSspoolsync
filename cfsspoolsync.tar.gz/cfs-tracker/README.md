# CFS Filament Tracker

Filamentverwaltung für den Creality K2 Combo mit CFS.

## Deployment auf Dockge (192.168.178.201)

### 1. Verzeichnis anlegen

```bash
mkdir -p /opt/stacks/cfs-tracker
cd /opt/stacks/cfs-tracker
```

### 2. Dateien übertragen

Alle Projektdateien nach `/opt/stacks/cfs-tracker/` kopieren:

```
/opt/stacks/cfs-tracker/
├── docker-compose.yml
├── Dockerfile
├── requirements.txt
└── app/
    ├── __init__.py
    ├── main.py
    ├── database.py
    ├── models.py
    ├── services/
    │   ├── __init__.py
    │   ├── moonraker.py
    │   └── ssh_client.py
    └── static/
        ├── index.html
        ├── style.css
        └── app.js
```

### 3. SSH-Key prüfen

```bash
# Key muss vorhanden und lesbar sein
ls -la /root/.ssh/id_k2
# Verbindung testen
ssh -i /root/.ssh/id_k2 root@192.168.178.192 "cat /mnt/UDISK/creality/userdata/box/material_box_info.json | head -5"
```

### 4. Starten

```bash
cd /opt/stacks/cfs-tracker
docker compose up -d --build
```

In Dockge: Stack `cfs-tracker` anlegen, Pfad `/opt/stacks/cfs-tracker`.

### 5. App aufrufen

```
http://192.168.178.201:8080
```

---

## Workflow

### Neue Spule einlagern

1. **Lager** → **+ Neue Spule**
2. Im K2-Lese-Bereich: Slot auswählen (T1A–T1D) → **Von K2 lesen**
   - Füllt Material, Farbe, Temperaturen automatisch aus
3. **Anfangsgewicht** manuell eingeben (Netto-Gewicht des Filaments in g)
4. **Spule speichern**

### Spule in CFS-Slot einlegen

Variante A – aus dem CFS-Tab:
- Leeren Slot → **+ Spule einlegen** → Spule aus Liste wählen

Variante B – aus dem Lager-Tab:
- Spule → **Einlegen** → freien Slot wählen

### Spule nach Druck entfernen

- CFS-Tab → Slot → **Aus Slot entfernen** → zurück ins Lager

---

## Verbrauchsberechnung

```
Gramm = π × (Durchmesser_mm / 20)² × (Meter × 100) × Dichte_g_cm³
```

Moonraker-Polling (alle 10 s):
- Druckstart → Snapshot der remainLen aus CFS-JSON
- Druckende → Differenz berechnen → Gramm abziehen

---

## API-Endpunkte (Kurzübersicht)

| Methode | Pfad | Beschreibung |
|---------|------|--------------|
| GET | `/api/spools` | Alle Spulen |
| POST | `/api/spools` | Spule anlegen |
| PUT | `/api/spools/{id}` | Spule bearbeiten |
| DELETE | `/api/spools/{id}` | Spule löschen |
| GET | `/api/cfs` | CFS-Zustand (DB) |
| GET | `/api/cfs/live` | CFS live vom K2 |
| GET | `/api/cfs/slot/{n}/read` | Slot live lesen |
| POST | `/api/cfs/slot/{n}/assign/{id}` | Spule in Slot |
| POST | `/api/cfs/slot/{n}/remove` | Spule aus Slot |
| GET | `/api/printer/status` | Moonraker-Status |
| GET | `/api/jobs` | Druckjobs |

---

## Logs

```bash
docker logs cfs-tracker -f
```

## Datenbank

SQLite unter `/opt/stacks/cfs-tracker/data/cfs.db`  
Backup: `cp data/cfs.db data/cfs.db.bak`
