#!/usr/bin/env bash
# deploy.sh – Überträgt den CFS Tracker auf den Dockge-Server und startet ihn neu
# Aufruf: ./deploy.sh [--build]

set -euo pipefail

REMOTE_HOST="192.168.178.201"
REMOTE_USER="root"
REMOTE_PATH="/opt/stacks/cfs-tracker"
SSH_KEY="${SSH_KEY:-$HOME/.ssh/id_rsa}"
BUILD="${1:-}"

echo "==> CFS Tracker Deploy"
echo "    Ziel: ${REMOTE_USER}@${REMOTE_HOST}:${REMOTE_PATH}"
echo ""

# 1. Verzeichnis auf Remote anlegen
ssh -i "$SSH_KEY" "${REMOTE_USER}@${REMOTE_HOST}" "mkdir -p '${REMOTE_PATH}/data'"

# 2. Dateien übertragen (außer data/)
rsync -avz --exclude='data/' --exclude='__pycache__' --exclude='*.pyc' \
  -e "ssh -i $SSH_KEY" \
  ./ "${REMOTE_USER}@${REMOTE_HOST}:${REMOTE_PATH}/"

echo ""
echo "==> Dateien übertragen"

# 3. Container neu starten
if [[ "$BUILD" == "--build" ]]; then
  echo "==> Container wird neu gebaut und gestartet…"
  ssh -i "$SSH_KEY" "${REMOTE_USER}@${REMOTE_HOST}" \
    "cd '${REMOTE_PATH}' && docker compose up -d --build"
else
  echo "==> Container wird neu gestartet…"
  ssh -i "$SSH_KEY" "${REMOTE_USER}@${REMOTE_HOST}" \
    "cd '${REMOTE_PATH}' && docker compose restart"
fi

echo ""
echo "✓ Fertig – App: http://${REMOTE_HOST}:8080"
